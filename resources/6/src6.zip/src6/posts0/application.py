import time

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/posts", methods=["POST"])
def posts():

    # Получить начальное и конечное значение генерируемых постов.
    start = int(request.form.get("start") or 0)
    end = int(request.form.get("end") or (start + 9))

    # Генерация списка постов.
    data = []
    for i in range(start, end + 1):
        data.append(f"Post #{i}")

    # Намеренно замедлить ответ сервера.
    time.sleep(1)

    # Вернуть список постов.
    return jsonify(data)
