cursor.execute("INSERT INTO library (name, author, genre, language) \
VALUES (%s, %s, %s, %s)", (nam, auth, gen, lang))
