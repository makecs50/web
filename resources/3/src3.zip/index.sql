CREATE INDEX duration_index ON flights (duration);
