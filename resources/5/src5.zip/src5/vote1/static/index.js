document.addEventListener('DOMContentLoaded', () => {

    // Подключение к websocket'у
    var socket = io.connect(location.protocol + '//' + document.domain + ':' + location.port);

    // При подключении, настроить кнопки
    socket.on('connect', () => {

        // Каждая кнопка должна излучать (emit) событие "submit vote"
        document.querySelectorAll('button').forEach(button => {
            button.onclick = () => {
                const selection = button.dataset.vote;
                socket.emit('submit vote', {'selection': selection});
            };
        });
    });

    //  Добавление в неупорядоченный список, при объявлении нового голоса
    socket.on('vote totals', data => {
        document.querySelector('#yes').innerHTML = data.yes;
        document.querySelector('#no').innerHTML = data.no;
        document.querySelector('#maybe').innerHTML = data.maybe;
    });
});
