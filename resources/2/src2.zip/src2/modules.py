from functions import square

print(square(10))
