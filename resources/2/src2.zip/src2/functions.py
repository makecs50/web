def square(x):
    return x * x

for i in range(10):
    print("{} squared {}".format(i, square(i)))
